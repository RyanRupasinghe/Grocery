package com.example.grocery;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;

public class ProductDatabase {
    private static final String URL = "jdbc:mysql://localhost:3306/grocery_store_db";
    private static final String USER = "root";
    private static final String PASSWORD = "Ryan2005@";

    public static ObservableList<Product> getProducts() {
        ObservableList<Product> products = FXCollections.observableArrayList();  // Always creates a new list
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM products")) {

            while (rs.next()) {
                products.add(new Product(rs.getString("name"), rs.getString("category"), rs.getDouble("price"), rs.getInt("quantity")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return products;  // Always returns a fresh list
    }


    public static void addProduct(String name, String category, double price, int stock) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO products (name, category, price, quantity) VALUES (?, ?, ?, ?)")) {

            stmt.setString(1, name);
            stmt.setString(2, category);
            stmt.setDouble(3, price);
            stmt.setInt(4, stock);
            stmt.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
    public static ObservableList<Product> removeProduct(String name) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM products WHERE name = ?")) {

            stmt.setString(1, name);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return getProducts(); // Return updated product list after removal
    }

    public static ObservableList<Product> updateStock(String name, int quantityChange) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("UPDATE products SET quantity = quantity + ? WHERE name = ?")) {

            stmt.setInt(1, quantityChange);
            stmt.setString(2, name);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return getProducts();  // Return updated product list
    }


    public static double calculateTotalInventoryValue() {
        double total = 0;
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT price, quantity FROM products")) {

            while (rs.next()) {
                total += rs.getDouble("price") * rs.getInt("quantity");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return total;
    }
}
