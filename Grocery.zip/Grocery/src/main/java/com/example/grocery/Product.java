package com.example.grocery;

import javafx.beans.property.*;

public class Product {
    private final StringProperty name;
    private final StringProperty category;
    private final DoubleProperty price;
    private final IntegerProperty stock;

    public Product(String name, String category, double price, int stock) {
        this.name = new SimpleStringProperty(name);
        this.category = new SimpleStringProperty(category);
        this.price = new SimpleDoubleProperty(price);
        this.stock = new SimpleIntegerProperty(stock);
    }

    public StringProperty nameProperty() {
        return name;
    }
    public StringProperty categoryProperty() {
        return category;
    }
    public DoubleProperty priceProperty() {
        return price;
    }
    public IntegerProperty stockProperty() {
        return stock;
    }
}
