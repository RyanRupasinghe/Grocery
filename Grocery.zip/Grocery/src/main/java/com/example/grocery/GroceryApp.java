package com.example.grocery;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class GroceryApp extends Application {
    private TableView<Product> table = new TableView<>();

    @Override
    public void start(Stage primaryStage) {
        // Table Columns
        TableColumn<Product, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());

        TableColumn<Product, String> categoryColumn = new TableColumn<>("Category");
        categoryColumn.setCellValueFactory(cellData -> cellData.getValue().categoryProperty());

        TableColumn<Product, Double> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(cellData -> cellData.getValue().priceProperty().asObject());

        TableColumn<Product, Integer> stockColumn = new TableColumn<>("Stock");
        stockColumn.setCellValueFactory(cellData -> cellData.getValue().stockProperty().asObject());

        table.getColumns().addAll(nameColumn, categoryColumn, priceColumn, stockColumn);

        //Stock Management UI (Add & Remove Stock)
        TextField changeQuantityField = new TextField();
        changeQuantityField.setPromptText("Quantity to Change");
        TextField stockNameField = new TextField();
        stockNameField.setPromptText("Product Name");
        Label inventoryValueLabel = new Label("Total Inventory Value: $" + ProductDatabase.calculateTotalInventoryValue());
        Button addStockButton = new Button("Add Stock");
        addStockButton.setOnAction(e -> {
            String name = stockNameField.getText();
            int quantityToAdd = Integer.parseInt(changeQuantityField.getText());
            table.setItems(ProductDatabase.updateStock(name, +quantityToAdd));
            table.refresh();  // makes the ui update
            inventoryValueLabel.setText("Total Inventory Value: $" + ProductDatabase.calculateTotalInventoryValue());
        });

        Button removeStockButton = new Button("Remove Stock");


        removeStockButton.setOnAction(e -> {
            String name = stockNameField.getText();
            int quantityToRemove = Integer.parseInt(changeQuantityField.getText());
            table.setItems(ProductDatabase.updateStock(name, -quantityToRemove));  // Update stock
            table.refresh();  // makes the ui update
            inventoryValueLabel.setText("Total Inventory Value: $" + ProductDatabase.calculateTotalInventoryValue());
        });


        // Fetch initial data from database
        table.setItems(ProductDatabase.getProducts());

        // Input Fields for Adding Products
        TextField nameField = new TextField();
        nameField.setPromptText("Product Name");

        TextField categoryField = new TextField();
        categoryField.setPromptText("Category");

        TextField priceField = new TextField();
        priceField.setPromptText("Price");

        TextField stockField = new TextField();
        stockField.setPromptText("Stock Quantity");

        Button addButton = new Button("Add Product");
        addButton.setOnAction(e -> {
            addProduct(nameField, categoryField, priceField, stockField);
        });
        TextField removeNameField = new TextField();
        removeNameField.setPromptText("Product Name");

        Button removeProductButton = new Button("Remove Product");
        removeProductButton.setOnAction(e -> {
            String name = removeNameField.getText();
            table.setItems(ProductDatabase.removeProduct(name));  // Refresh TableView dynamically
        });



        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));  // Adds space around the UI
        layout.getChildren().addAll(table, nameField, categoryField, priceField, stockField, addButton, stockNameField, changeQuantityField, addStockButton, removeStockButton, inventoryValueLabel, removeNameField, removeProductButton);
        layout.setSpacing(10);
        layout.setSpacing(10);

        primaryStage.setScene(new Scene(layout, 800, 600));  // Bigger window size        primaryStage.setTitle("Grocery Store Management");
        primaryStage.show();
    }

    private void addProduct(TextField nameField, TextField categoryField, TextField priceField, TextField stockField) {
        String name = nameField.getText();
        String category = categoryField.getText();
        double price = Double.parseDouble(priceField.getText());
        int stock = Integer.parseInt(stockField.getText());

        ProductDatabase.addProduct(name, category, price, stock);

        // Refresh table data
        table.setItems(ProductDatabase.getProducts());
    }
    private void removeProduct(TextField nameField) {
        String name = nameField.getText();

        ProductDatabase.removeProduct(name);

        // Refresh table data
        table.setItems(ProductDatabase.getProducts());
    }


    public static void main(String[] args) { launch(args); }
}
